#!/usr/bin/env python

import rospy, serial
from std_msgs.msg import UInt8, Float64, Bool
import serial.tools.list_ports as ports

#wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww

#steering_ArduinoSerialNo = "5573132313635130B2A1"
steering_ArduinoSerialNo = "5573132313635140E0C1"
#brake_throttle_ArduinoSerialNo = "55731323136351407091"
brake_throttle_ArduinoSerialNo = "55731323136351407091"

baudrate = 115200


class ArduinoInterface():
    def __init__(self):
        rospy.init_node('arduino_interface', anonymous=False)

        self.brakeValue = 0.0
        self.throttleValue = 0.0
        self.gearValue = 0
        self.signalValue = 3
        self.isNewBrkThrValueReceived = True
        self.isSteeringCalibrated = False
        
        print("")
        # rospy.sleep(2)
        [steeringAddress, brakeAddress] = self.IdentifyDevice()
        if(steeringAddress == "" or brakeAddress == ""):
            if(steeringAddress == ""):
                print("Steering Device detection problem. Exiting!")
            if(brakeAddress == ""):
                print("Brake Device detection problem. Exiting!")
            exit()

        # https://pyserial.readthedocs.io/en/latest/pyserial_api.html
        self.steeringDev = serial.Serial(port=steeringAddress, baudrate=baudrate, timeout=6.0)
        self.brakeThrottleDev = serial.Serial(port=brakeAddress, baudrate=baudrate, timeout=1.0)
        rospy.sleep(1)

        rospy.Subscriber("/brake_cmd", Float64, self.cb_Brake)
        rospy.Subscriber("/throttle_cmd", Float64, self.cb_Throttle)
        rospy.Subscriber("/steering_cmd", Float64, self.cb_Steering)
        rospy.Subscriber("/signal_cmd", UInt8, self.cb_Signal)
        rospy.Subscriber("/gear_cmd", UInt8, self.cb_Gear)
        self.pub_calibRes = rospy.Publisher("/steering_calibration", Bool, queue_size=10)

        print("\t\n... Arduino ROS interface Started ...\n")
        pass


    def Start(self):
        loopRate = rospy.Rate(5)
        rospy.sleep(1)
        while not rospy.is_shutdown():
            if self.isNewBrkThrValueReceived:
                self.isNewBrkThrValueReceived = False
                
                message = "/" + str(self.brakeValue) + ";" + str(self.throttleValue) + ";" + str(self.gearValue) + ";" + str(self.signalValue) + "/"
               
                self.brakeThrottleDev.writelines(message)
                while self.brakeThrottleDev.out_waiting > 0 :
                    pass
                
                res = self.brakeThrottleDev.readline()
                # print(res)
            loopRate.sleep()

        message = "/" + str(0) + ";" + str(0) + ";" + str(0) + "/"
        self.brakeThrottleDev.writelines(message)


    def cb_Gear(self, msg):
        self.isNewBrkThrValueReceived = True
        self.gearValue = msg.data


    def cb_Brake(self, msg):
        self.isNewBrkThrValueReceived = True
        self.brakeValue = msg.data


    def cb_Throttle(self, msg):
        self.isNewBrkThrValueReceived = True
        self.throttleValue = msg.data


    def cb_Signal(self, msg):
        self.isNewBrkThrValueReceived = True
        self.signalValue = msg.data


    def cb_Steering(self, msg):
        angleMsg = "/" + str(msg.data) + "/"
        # print(angleMsg)

        self.steeringDev.writelines(angleMsg)
        while self.steeringDev.out_waiting > 0 :
            pass

        res = self.steeringDev.readline() # receive sent message back
        # print(res)


        if not self.isSteeringCalibrated:
            self.isSteeringCalibrated = True

            calibResMsg = Bool()
            if res.strip() == "CAL OK":
                calibResMsg.data = True
                self.pub_calibRes.publish(calibResMsg)
                print("Steering calibration finished.")
            else:
                calibResMsg.data = False
                self.pub_calibRes.publish(calibResMsg)


    def IdentifyDevice(self):
        deviceInfos = list(ports.comports())
        steeringAddress = ""
        brakeAddress = ""

        if len(deviceInfos) > 0:
            for p  in deviceInfos:
                if p.serial_number == brake_throttle_ArduinoSerialNo:
                    brakeAddress = p.device
                    print("Brake and Throttle Arduino is detected in : " + brakeAddress)
                elif p.serial_number == steering_ArduinoSerialNo:
                    steeringAddress = p.device
                    print("Steering Arduino is detected in : " + steeringAddress)

        return [steeringAddress, brakeAddress]
        pass



if __name__ == "__main__":
    try:
        arduinoInterface = ArduinoInterface()
        arduinoInterface.Start()
        print("\t\n... Arduino ROS interface EXITED ...\n")
    except rospy.ROSInterruptException:
        pass
