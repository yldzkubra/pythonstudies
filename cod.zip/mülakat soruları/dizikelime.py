# Given is the main program shown. You have to write the method/function to complete the code.
# For us it is more important to see how you write the code than a functioning code, so please do not write the code in anywhere else and then copy and paste it here.

# Given a string s and a list of words words, where each word is the same length, find all starting indices of substrings in s that is a concatenation of every word in words exactly once.

# For example, given s = "dogcatcatcodecatdog" and words = ["cat", "dog"], return [0, 13], since "dogcat" starts at index 0 and "catdog" starts at index 13.

# Given s = "barfoobazbitbyte" and words = ["dog", "cat"], return [] since there are no substrings composed of "dog" and "cat" in s.

# The order of the indices does not matter.

def findSubstring(s, words):
    if not s or not words:
        return []

    word_len = len(words[0])  # Her kelimenin uzunluğu
    word_count = len(words)  # Kelime sayısı
    total_len = word_len * word_count  # Aranacak alt dizenin toplam uzunluğu
    word_map = {}

    # Kelime listesindeki her kelimenin sayısını hesapla
    for word in words:
        word_map[word] = word_map.get(word, 0) + 1

    result = []

    # s içinde kelimelerin birleşimlerini kontrol et
    for i in range(len(s) - total_len + 1):
        seen = {}
        j = 0
        while j < word_count:
            word = s[i + j * word_len:i + (j + 1) * word_len]
            if word in word_map:
                seen[word] = seen.get(word, 0) + 1
                if seen[word] > word_map[word]:
                    break
            else:
                break
            j += 1
        if j == word_count:
            result.append(i)

    return result

# Örnek kullanım
s1 = "dogcatcatcodecatdog"
words1 = ["cat", "dog"]
print(findSubstring(s1, words1))  # Çıktı: [0, 13]

s2 = "barfoobazbitbyte"
words2 = ["dog", "cat"]
print(findSubstring(s2, words2))  # Çıktı: []