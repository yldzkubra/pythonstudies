#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
import numpy as np 
import matplotlib.pyplot as plt 
import pandas as pd 


# Veri yükleme 
data = pd.read_csv('data.csv')
#print(data)

# Eksik veri tamamlama (ortalama ile)
imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
# Hangi kolonlarda eksik veri olduğunu belirtmek için veriyi seçiyoruz
age = data.iloc[:, 1:4]
# İmputer'ı fit ve transform ederek eksik verileri tamamlıyoruz
imputer = imputer.fit(age)
age = imputer.transform(age)
# Doldurulmuş verileri orijinal DataFrame'e geri yazıyoruz
data.iloc[:, 1:4] = age
# Sonuçları kontrol etmek için veriyi yazdırıyoruz
#print(data)

# Ülke verilerini label encoding için hazırlık
country = data.iloc[:, 0].values  # Extract as a 1D array suitable for LabelEncoder
le = preprocessing.LabelEncoder()
country_encoded = le.fit_transform(country)
#print(country_encoded)

# One-hcot enoding
ohe = preprocessing.OneHotEncoder()
country_encoded = country_encoded.reshape(-1, 1)  # Reshape to 2D array necessary for OneHotEncoder
country_ohe = ohe.fit_transform(country_encoded).toarray()
#print(country_ohe)


#birleştirme 
cinsiyet = data.iloc[:,-1].values

result = pd.DataFrame(data = country_ohe, index = range(20), columns = ['fr', 'tr', 'us'])
result2 = pd.DataFrame(data = data, index = range(20), columns = ['boy', 'kilo', 'yas'])
result3 = pd.DataFrame(data = cinsiyet, index = range(20), columns = ['cinsiyet'])

s = pd.concat([result, result2], axis=1)
print(s)

s2 = pd.concat([s, result3], axis=1)
print(s2)


#train test ayırma
x_train, x_test, y_train, y_test = train_test_split(s, result3, test_size=0.33, random_state=0)
print(x_test)


#öznitelik ölçeklendirme
sc = StandardScaler()
X_train = sc.fit_transform(x_train)
X_test = sc.fit_transform(x_test)
print(X_test)

Y_train = sc.fit_transform(y_train)
Y_test = sc.fit_transform(y_test)


#model insası (linear regrasyon)
lr =  LinearRegression()
lr.fit(X_train, Y_train)
