# LİNK : https://www.youtube.com/watch?v=xX5iOYCJmBI&list=PLZPZq0r_RZON1eaqfafTnEexRzuHbfZX8



# Bracket Combinations
# Have the function BracketCombinations(num) read num which will be an integer greater than 
# or equal to zero, and return the number of valid combinations that can be formed with num 
# pairs of parentheses. For example, if the input is 3, then the possible combinations of 
# 3 pairs of parenthesis, namely: ()()(), are ()()(), ()(()), (())(), ((())), and (()()). 
# There are 5 total combinations when the input is 3, so your program should return 5.

from math import factorial

def BracketCombinations(num):
  return int(factorial(2 * num) / (factorial(num + 1) * factorial(num)))
  # code goes here
  # return num

# keep this function call here 
print(BracketCombinations(input()))

# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# MinWindowSubstring(strArr) fonksiyonunu yazmanız isteniyor. Bu fonksiyon, içinde sadece iki string bulunan bir dizi olan strArr dizisini alacak. 
# İlk parametre, string N; ikinci parametre ise bazı karakterlerden oluşan string K olacak. Amacınız, N içerisinde K'deki tüm karakterleri içeren en küçük alt diziyi bulmak.
# Örneğin: eğer strArr değeri ["aaabaaddae", "aed"] ise, N stringi içinde a, e ve d karakterlerini içeren en küçük alt dize "dae" olur ve bu dize stringin sonunda yer alır. 
# Yani bu örnek için fonksiyonunuz "dae" döndürmelidir.Başka bir örnek: Eğer strArr değeri ["aabdccdbcacd", "aad"] ise, N stringi içinde tüm "aad" karakterlerini içeren en küçük
#  alt dize "aabd" olur ve bu dize stringin başında yer alır.

# Her iki string de 1 ile 50 karakter arasında olacak ve K'deki tüm karakterler N içerisinde bir yerlerde bulunacak. Her iki string de sadece küçük harflerden oluşacak.
# Examples
# Input: ["ahffaksfajeeubsne", "jefaa"]
# Output: aksfaje
# Input: ["aaffhkksemckelloe", "fhea"]
# Output: affhkkse

from collections import Counter

EMPTY_COUNTER = Counter()

def MinWindowSubstring(strArr):
  N, K = strArr
  frequencyK = Counter(K)
  options = []
  for i in range(len(N)):
    curr = Counter()
    for j in range(i, len(N)):
      curr[N[j]] += 1
      if frequencyK - curr == EMPTY_COUNTER:
        options.append(N[i:j + 1])
        break
  return min(options, key=len)
      

# keep this function call here 
print(MinWindowSubstring(input()))

# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# ------------------------------------------------CEZERİ ---------------------------------------------

# Tree Constructor
# Have the function TreeConstructor(strArr) take the array of strings stored in strArr, which will contain pairs of 
# integers in the following format: (i1,i2), where i1 represents a child node in a tree and the second integer i2 
# signifies that it is the parent of i1. For example: if strArr is ["(1,2)", "(2,4)", "(7,2)"], then this forms the
# following tree:
# which you can see forms a proper binary tree. Your program should, in this case, return the string true because a valid 
# binary tree can be formed. If a proper binary tree cannot be formed with the integer pairs, then return the string false.
# All of the integers within the tree will be unique, which means there can only be one node in the tree with the given 
# integer value.
# Examples
# Input: ["(1,2)", "(2,4)", "(5,7)", "(7,2)", "(9,5)"]
# Output: true
# Input: ["(1,2)", "(3,2)", "(2,12)", "(5,2)"]
# Output: false

def TreeConstructor(strArr):
  parentList = []
  for node in strArr:
    child,parent = eval(node)
    parentList.append(parent)
    if parentList.count(parent) > 2:
      return "false"
  return "true"
  # code goes here
# keep this function call here 
print(TreeConstructor(input()))

# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# Array Challenge

# Have the function ArrayChallenge (arr) take the array of integers stored in arr, and for each element in the list, search all 
# the previous values for the nearest element that is smaller than (or equal to) the current element and create a new list from 
# these numbers. If there is no element before a certain position that is smaller, input a -1. For example: if arr is 
# [5, 2, 8, 3, 9, 12] then the nearest smaller values list is [-1, -1, 2, 2, 3, 9]. The logic is as follows:
# For 5, there is no smaller previous value so the list so far is [-1]. For 2, there is also no smaller previous value, so the 
# list is now [-1,-1]. For 8, the nearest smaller value is 2 so the list is now [-1, -1, 2]. For 3, the nearest smaller value is 
# also 2, so the list is now [-1, -1, 2, 2]. This goes on to produce the answer above. Your program should take this final list
#  and return the elements as a string separated by a space: -1-12239
# Examples
# Input: [5, 3, 1, 9, 7, 3, 4, 1]
# Output: 1 -1 -1 1 1 1 3 1
# Input: [2, 4, 5, 1, 7]
# Output: 1 2 4 -1 1

def ArrayChallenge(arr):
    result = []
    for i in range(len(arr)):
        nearest_smaller = -1
        for j in range(i - 1, -1, -1):
            if arr[j] <= arr[i]:
                nearest_smaller = arr[j]
                break
        result.append(str(nearest_smaller))
    return ''.join(result)
# keep this function call here 
print(TreeConstructor(input()))


# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# String Challenge
# Have the function StringChallenge (str) take the str parameter being passed and return a compressed version of the string
#  using the Run-length encoding algorithm. This algorithm works by taking the occurrence of each repeating character and 
# outputting that number along with a single character of the repeating sequence. For example: "wwwggopp" would return 
# 3w2g102p. The string will not contain any numbers, punctuation, or symbols.
# Examples
# Input: "aabbcde"
# Output: 2a2b1c1d1e 

def StringChallenge(s):
    result, count = [], 1
    for i in range(1, len(s)):
        if s[i] == s[i - 1]:
            count += 1
        else:
            result.append(f"{count}{s[i - 1]}")
            count = 1

    result.append(f"{count}{s[-1]}")
    return ''.join(result)
# keep this function call here 
print(StringChallenge(input()))


# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# BracketMatcher(str) fonksiyonu, verilen str parametresini almalı ve parantezlerin doğru bir şekilde eşleşip eşleşmediğini kontrol etmelidir. 
# Eğer parantezler doğru bir şekilde eşleşiyorsa, fonksiyon 1 döndürmeli. Eğer eşleşme doğru değilse 0 döndürmelidir. Örneğin: eğer str "(hello (world))" 
# ise, çıktı 1 olmalı, ancak str "((hello (world))" olduğunda çıktı 0 olmalıdır çünkü parantezler doğru bir şekilde eşleşmemiştir. Sadece "(" ve ")" karakterleri
#  parantez olarak kullanılacaktır. Eğer str içinde parantez yoksa 1 döndürmelidir.
#  Examples
# Input: "(coder)(byte))"
# Output: 0
# Input: "(c(oder)) b(yte)"
# Output: 1

def BracketMatcher(s):
  count = 0
  for char in s:
      if char == "(":
          count += 1
      elif char == ")":
          count -= 1
      if count < 0:
          return 0
  return 1 if count == 0 else 0

print(BracketMatcher(input()))

# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# Problem: Codeland Kullanıcı Adı Doğrulama
# CodelandUsernameValidation(str) fonksiyonu, verilen str parametresinin geçerli bir kullanıcı adı olup olmadığını kontrol etmelidir.
#  Geçerli bir kullanıcı adı aşağıdaki kurallara göre belirlenir:
# Kullanıcı adı 4 ile 25 karakter arasında olmalıdır.
# Kullanıcı adı bir harf ile başlamalıdır.
# Kullanıcı adı yalnızca harfler, rakamlar ve alt çizgi (_) karakterini içerebilir.
# Kullanıcı adı alt çizgi (_) ile bitemez.
# Eğer kullanıcı adı geçerli ise, fonksiyon "true" döndürmeli, aksi durumda "false" döndürmelidir.

def CodelandUsernameValidation(s):
  if len(s)>4 and len(s)<25 and s[0].isalpha() and [i for i in s if i.isalnum() or i=="_"]!=[] and s[-1]!="_":
    return True
  else:
    return False
# keep this function call here 
print(CodelandUsernameValidation(input()))

# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# Problem: Kesişim Bulma

# FindIntersection(strArr) fonksiyonu, strArr içinde depolanan iki stringden oluşan diziyi okuyacaktır. Bu dizideki 
# iki eleman, virgülle ayrılmış sayılardan oluşan iki listeyi temsil edecektir. İlk eleman artan sırada sıralanmış bir 
# sayı listesi, ikinci eleman ise yine artan sırada sıralanmış başka bir sayı listesini içerir. Amacınız, bu iki listenin
#  kesişiminde bulunan sayıları virgülle ayrılmış bir string olarak döndürmektir. Eğer kesişim yoksa, fonksiyon "false" döndürmelidir.

# Örnekler:
# Girdi: ["1, 3, 4, 7, 13", "1, 2, 4, 13, 15"]
# Çıktı: "1,4,13" (Çünkü 1, 4 ve 13 her iki listede de var)
# Girdi: ["1, 3, 9, 10, 17, 18", "1, 4, 9, 10"]
# Çıktı: "1,9,10" (Çünkü 1, 9 ve 10 her iki listede de var)

def FindIntersection(strArr):
    return ','.join(sorted(set(strArr[0].split(", ")) & set(strArr[1].split(", ")), key=int)) or "false"

print(FindIntersection(input()))

# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# Problem: Soru İşaretleri

# QuestionsMarks(str) fonksiyonu, verilen str string parametresini alacak ve bu string içinde tek basamaklı sayılar, harfler ve 
# soru işaretleri bulunacak. Görevimiz, string içinde toplamı 10 olan her iki sayı çifti arasında tam olarak 3 soru işareti olup 
# olmadığını kontrol etmektir. Eğer bu koşul sağlanıyorsa, fonksiyon "true" döndürecek, aksi durumda "false" döndürecektir. Ayrıca, 
# string içinde toplamı 10 olan hiçbir iki sayı çifti yoksa, fonksiyon yine "false" döndürmelidir.
# Examples
# Input: "aa6?9"
# Output: false
# Input: "acc?7??sss?3rr1??????5"
# Output: true

def QuestionsMarks(s):
    found_pair = False
    for i in range(len(s)):
        if s[i].isdigit():
            for j in range(i + 1, len(s)):
                if s[j].isdigit() and int(s[i]) + int(s[j]) == 10:
                    if s[i+1:j].count('?') == 3:
                        found_pair = True
                    else:
                        return "false"
    return "true" if found_pair else "false"


print(QuestionsMarks(input()))
# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# Problem: İlk Faktöriyel (First Factorial)

# FirstFactorial(num) fonksiyonu, verilen num parametresinin faktöriyelini hesaplamalı ve sonucu döndürmelidir. 
# Örneğin: eğer num = 4 ise, fonksiyon (4 * 3 * 2 * 1) = 24 sonucunu döndürmelidir. Test senaryolarında num 1 
# ile 18 arasında olacak ve her zaman bir tamsayı olarak verilecektir.
# Örnekler:
# Girdi: 4
# Çıktı: 24
# Girdi: 8
# Çıktı: 40320


def FirstFactorial(num): 
    if num == 1:
      return 1
    else:
      return num * FirstFactorial(num-1)
    # code goes here 
    # return num
    
# keep this function call here  
print(FirstFactorial(input()))

# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************

# Problem: En Uzun Kelime (Longest Word)

# LongestWord(sen) fonksiyonu, verilen sen parametresindeki stringdeki en uzun kelimeyi bulmalı ve döndürmelidir.
#  Eğer aynı uzunlukta birden fazla kelime varsa, stringde en önce geleni döndürmelidir. Noktalama işaretleri göz 
#  ardı edilmelidir ve sen parametresi boş olmayacaktır. Ayrıca kelimeler rakamlar da içerebilir.

# Örnekler:
# Girdi: "fun&!! time"
# Çıktı: "time" (Noktalama işaretleri göz ardı edilince, "fun" ve "time" kalır ve "time" en uzun olan kelimedir)
# Girdi: "I love dogs"
# Çıktı: "love" (En uzun kelime "love"dir)

import re

def LongestWord(sen):
    words = re.findall(r'\w+', sen)
    # En uzun kelimeyi bul ve döndür
    return max(words, key=len)

print(LongestWord(input()))
# -----------------------------------------------------------------------------------------------------
#******************************************************************************************************
