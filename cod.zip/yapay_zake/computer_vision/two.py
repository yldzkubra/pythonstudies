# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import cv2

img = cv2.imread('/home/kubra/Pictures/ttt.png')
print(img.shape)
print(type(img))

# matplotlib --> red green blue
#opencv --> blue green red
# Orijinal resmi çizmek için imshow
plt.imshow(img)
plt.title("Orijinal Resim")
plt.show()

# BGR TO RGB
fix_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
plt.imshow(fix_img)
plt.title("Orijinal TO Resim")
plt.show()

#GRİ TONLAAMALI
img_gray = cv2.imread('/home/kubra/Pictures/ttt.png', cv2.IMREAD_GRAYSCALE)
print(img_gray.shape)
plt.imshow(img_gray, cmap='gray')
plt.title("gri tonlamali")
plt.show()

#boyutu kücültme
new_img = cv2.resize(fix_img,(1000, 400))
plt.imshow(new_img)
plt.title("boyutu farkli Resim")
plt.show()

w_ratio, h_ratio = 2.0, 2.0
new_img = cv2.resize(fix_img,(0, 0), fix_img, w_ratio, h_ratio)
plt.imshow(new_img)
plt.title("boyutu oranla farkli Resim")
plt.show()

#ters cevirme
new_img = cv2.flip(fix_img, 0)
plt.imshow(new_img)
plt.title("ters cevirme")
plt.show()

# Kaydetme
cv2.imwrite('/home/kubra/Desktop/computer_vision/tot.jpg', fix_img)

fig = plt.figure(figsize=(10,8))
ax = fig.add_subplot(111)
ax.imshow(fix_img)
plt.show()





