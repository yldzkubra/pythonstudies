# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt 
from PIL import Image

# Resmi yükleme
pic = Image.open('/home/kubra/Pictures/ttt.png')
print(type(pic))

# Resmi NumPy array'ine çevirme
pic_arr = np.asarray(pic)
print(type(pic_arr))

# Resim boyutlarını yazdırma (yükseklik, genişlik, renk kanalları)
print(pic_arr.shape)

# Orijinal resmi çizmek için imshow
plt.imshow(pic_arr)
plt.title("Orijinal Resim")
plt.show()

# Kırmızı kanal (R) - 0. kanal
plt.imshow(pic_arr[:, :, 0], cmap='gray')
plt.title("Kırmızı Kanal")
plt.show()

# Yeşil kanal (G) - 1. kanal
plt.imshow(pic_arr[:, :, 1], cmap='gray')
plt.title("Yeşil Kanal")
plt.show()

# Mavi kanal (B) - 2. kanal
plt.imshow(pic_arr[:, :, 2], cmap='gray')
plt.title("Mavi Kanal")
plt.show()

# Yeşil kanalı iptal etmek (0 yapmak) için resmi kopyalama
pic_arr_no_green = pic_arr.copy()
pic_arr_no_green[:, :, 1] = 0  
plt.imshow(pic_arr_no_green)
plt.title("Yeşil Kanal iptal")
plt.show()


pic_arr_no_green[:, :, 2] = 0 
plt.imshow(pic_arr_no_green)
plt.title("Yeşil ve mavi Kanal iptal")
plt.show()