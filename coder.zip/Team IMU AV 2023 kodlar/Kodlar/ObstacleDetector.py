#!/usr/bin/env python

import rospy
import numpy as np
from math import sin, cos, degrees, radians, atan
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Bool, Float64MultiArray

#wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww


frontObstacledDist = 1.4 # meters | min engel mesafesi
frontClearance = 1.2 # meters | on aciklik


class ObstacleDetector():

    def __init__(self):
        rospy.init_node('obstacle_detector', anonymous=False)

        self.maxLidarDist = 40 # m

        self.lidarData = np.array(np.zeros(720))
        
        rospy.Subscriber("/scan", LaserScan, self.cb_ReadLidarData)
        self.pub_obstacle= rospy.Publisher("/obstacle/is_obstacle_detected", Bool, queue_size=10)
        self.pub_distance= rospy.Publisher("/obstacle/distances", Float64MultiArray, queue_size=10)

        print("\t\n...  Obstacle Detector Started ...\n")


    def cb_ReadLidarData(self, msg):
        self.lidarData = np.array(msg.ranges)


    def Polar2Cartesian(self, polarDisatnceList, angle):
        # angle [degrees] = starting angle of the scan data
        cartesianDistanceList = []

        for d in polarDisatnceList:
            if d != np.inf:
                if angle != 90 or angle != 270:
                    x = abs(d * cos(radians(angle)))
                else:
                    x = 0.0

                if angle != 180 or angle != 360:
                    y = abs(d * sin(radians(angle)))
                else:
                    y = 0.0

                cartesianDistanceList.append([x,y])

            angle += 0.5

        return np.array(cartesianDistanceList)


    def CheckObstacles(self):
        loopRate = rospy.Rate(10)
        while not rospy.is_shutdown():
            frontHalfScanAreaAngle = int(degrees(atan(frontClearance/(2 * frontObstacledDist))))
            frontStartAngle = int(270 - frontHalfScanAreaAngle)

            rightStartAngle = 180
            rightStartIndex = 360 # 720 sample
            rightEndIndex = int(frontStartAngle * 2)
            rightPolarDist = self.lidarData[rightStartIndex : rightEndIndex]
            rightCoordList = self.Polar2Cartesian(rightPolarDist, rightStartAngle)

            frontStartIndex = int(frontStartAngle * 2)
            frontEndIndex = int(frontStartAngle * 2 + frontHalfScanAreaAngle * 4)
            frontPolarDist = self.lidarData[frontStartIndex : frontEndIndex]
            frontCoordList = self.Polar2Cartesian(frontPolarDist, frontStartAngle)

            leftStartAngle = int(270 + frontHalfScanAreaAngle)
            leftEndIndex = 719
            leftPolarDist = self.lidarData[leftStartAngle * 2 : leftEndIndex]
            leftCoordDist = self.Polar2Cartesian(leftPolarDist, leftStartAngle)

            result = False

            rightMinDist = 40
            frontMinDist = 40
            leftMinDist = 40

            # wwwwwwwwwwwwwwwwwwwwww
            self.infErrorLeft = False
            try:
                rightMinDist = np.min(rightCoordList[:, 0]) # x
                rightMeanDist = np.mean(rightCoordList[:, 0]) # x
            except:
                result = False # lidar inf
                self.infErrorLeft = True
            # wwwwwwwwwwwwwwwwwwwwww
            self.infErrorFront = False
            try:
                frontMinDist = np.min(frontCoordList[:, 1]) # y
                frontMeanDist = np.mean(frontCoordList[:, 1]) # y
            except:
                result = False # lidar inf
                self.infErrorFront = True
            # wwwwwwwwwwwwwwwwwwwwww
            self.infErrorRight = False
            try:
                leftMinDist = np.min(leftCoordDist[:, 0]) # x
                leftMeanDist = np.mean(leftCoordDist[:, 0]) # x
            except:
                result = False # lidar inf
                self.infErrorRight = True
            # wwwwwwwwwwwwwwwwwwwwww

            if not self.infErrorLeft and leftMinDist < (frontClearance / 2.0):
                result = True

            if not self.infErrorFront and frontMinDist < frontObstacledDist:
                result = True

            if not self.infErrorRight and rightMinDist < (frontClearance / 2.0):
                result = True

            # print(result)
            # print("sag",rightMinDist, "on", frontMinDist, "sol", leftMinDist)
            # print("sag_",rightMeanDist, "on_", frontMeanDist, "sol_", leftMeanDist)

            msg = Bool()
            msg.data = result
            self.pub_obstacle.publish(msg)

            distanceListMsg = Float64MultiArray()
            distanceListMsg.data.append(leftMinDist)
            distanceListMsg.data.append(frontMinDist)
            distanceListMsg.data.append(rightMinDist)

            distanceListMsg.data.append(leftMeanDist)
            distanceListMsg.data.append(frontMeanDist)
            distanceListMsg.data.append(rightMeanDist)
            self.pub_distance.publish(distanceListMsg)
            loopRate.sleep()



if __name__ == "__main__":
    try:
        obstacleDetector = ObstacleDetector()
        obstacleDetector.CheckObstacles()
        print("\t\n... Obstacle Detector EXITED ...\n")
    except rospy.ROSInterruptException:
        pass
