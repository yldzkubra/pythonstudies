#!/usr/bin/env python

import rospy
from sensor_msgs.msg import NavSatFix
from std_msgs.msg import String

#wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww

# "/status;pct:80;volt:50;curr:2;vel:5.5;head:180;lat:40.99616788943276;lon:29.06418927005051/"

class MessageGenertor():
    def __init__(self):
        rospy.init_node('message_generator', anonymous=False)
        
        rospy.Subscriber("/gps/fix", NavSatFix, self.cb_GPS)
        self.pub_Telem = rospy.Publisher('/telem_comm/send_data', String, queue_size=10)

        self.isGPSReceived = False
        self.GSP = NavSatFix()
        pass


    def cb_GPS(self, msg):
        self.isGPSReceived = True
        self.GPS = msg

        
    def Start(self):
        percentage = 100 # dummy
        voltage = 60 # dummy
        current = 3.2 # dummy
        velocity = 5
        heading = 0
        lat = 0
        lon = 0
        
        print("\t\n... Message Generator Started ...\n")

        loopRate = rospy.Rate(1)
        while not rospy.is_shutdown():
            if self.isGPSReceived:
                lat = self.GPS.latitude
                lon = self.GPS.longitude
            
            msgStr = "/status;pct:" + str(percentage) + ";volt:" + str(voltage) + ";curr:" + str(current) + ";vel:" + str(velocity) + ";head:" + str(heading) + ";lat:" + str(lat) + ";lon:" + str(lon) + "/"
            msg = String()
            msg.data = msgStr
            self.pub_Telem.publish(msg)
            loopRate.sleep()
            


if __name__ == "__main__":
    try:
        messageGenerator = MessageGenertor()
        messageGenerator.Start()
        print("\t\n... Message Generator EXITED ...\n")
    except rospy.ROSInterruptException:
        pass
