import cv2

img = cv2.imread('/home/kubra/Pictures/ttt.png')

while True:
    cv2.imshow('kkk',img)

    if cv2.waitKey(1) & 0xFF ==27:
        break

cv2.destroyAllWindows()