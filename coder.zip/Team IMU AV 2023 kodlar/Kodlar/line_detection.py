#!/usr/bin/env python



import rospy, cv2, sys
import numpy as np
from math import degrees, atan2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from std_msgs.msg import Float64, String



class LineDetection():
    
    def __init__(self):
        self.I = None
        self.isImgReceived = False
        self.arg = None

        if len(sys.argv) > 1:
            self.arg = sys.argv[1]

        print("wwwwwwwwwww")
        print(str(sys.argv))
        print(self.arg)
        print("wwwwwwwwwww")

        self.bridge = CvBridge()

        rospy.init_node('line_detection', anonymous=False)
        rospy.Subscriber("/usb_cam_line/image_raw", Image, self.cb_Image)
        self.pub_angle = rospy.Publisher('/line_detection/goal_angle', Float64, queue_size=10)
        self.pub_line = rospy.Publisher('/line_detection/lines', String, queue_size=10)
        print("\n\t... Line Detection Started ...\n")
        pass


    def cb_Image(self, msg):
        self.I = self.bridge.imgmsg_to_cv2(msg,"bgr8")
        self.isImgReceived = True
        pass


    def Start(self):
        print("Waiting for image topic...")
        waitLoop = rospy.Rate(2)
        while not self.isImgReceived and  not rospy.is_shutdown():
            waitLoop.sleep()

        print(self.I.shape)
        print("Image received.\n")

        mainLoop = rospy.Rate(5)
        while not rospy.is_shutdown():
            #self.ImgShow("Raw I", self.I, False)
            Ihsv = cv2.cvtColor(self.I,cv2.COLOR_RGB2HSV)

            sensitivity = 60
            lower_white = np.array([0,0,255-sensitivity])
            upper_white = np.array([255,sensitivity,255])

            # Select white
            Ith_noisy = cv2.inRange(Ihsv, lower_white, upper_white)
            


            # Make binary
            ret, Ith_noisy = cv2.threshold(Ith_noisy, 250, 1, cv2.THRESH_BINARY)

            # Remove noises
            kernel = np.ones((3, 3), np.uint8)
            Ith = cv2.morphologyEx(Ith_noisy, cv2.MORPH_OPEN, kernel)
            kernel = np.ones((15, 15), np.uint8)
            Ith = cv2.morphologyEx(Ith, cv2.MORPH_DILATE, kernel,2)

            #self.ImgShow("Ith", Ith*255)

            imgHeight, imgWidth = Ith.shape

            pt_A = [270,400]
            pt_B = [0,imgHeight]
            pt_C = [imgWidth,imgHeight]
            pt_D = [imgWidth - pt_A[0], pt_A[1]]

            input_pts = np.float32([pt_A, pt_B, pt_C, pt_D])
            output_pts = np.float32([[0, 0], [0, imgHeight], [imgWidth, imgHeight], [imgWidth, 0]])

            transMatrix = cv2.getPerspectiveTransform(input_pts, output_pts)
            I_warped = cv2.warpPerspective(Ith,transMatrix,(imgWidth, imgHeight),flags=cv2.INTER_LINEAR)


            leftLineMask, rightLineMask = self.ConnectedComponents(I_warped)

            rightLine = np.array(np.where(rightLineMask == 255))
            leftLine = np.array(np.where(leftLineMask == 255))

            followRight = False
            followLeft = False

            leftLineX = 0
            leftLineY = 0
            rightLineX = 0
            rightLineY = 0
            
            try:
                rightLineX = int( np.mean((rightLine[1,:])) )
                rightLineY = int( np.mean((rightLine[0,:])) )
                followLeft = False
            except:
                # Sag yoksa solu takip et
                followLeft = True


            try:
                leftLineX = int( np.mean((leftLine[1,:])) )
                leftLineY = int( np.mean((leftLine[0,:])) )
                followRight = False
            except:
                # Sol yoksa sagi takip et
                followRight = True


            if followLeft and followRight:
                goalAngle = Float64()
                goalAngle.data = 0
                self.pub_angle.publish(goalAngle)

                lineMsg = String()
                lineMsg.data = "none"
                self.pub_line.publish(lineMsg)
                continue

            elif followLeft:
                rightLineX = leftLineX + imgWidth
                rightLineY = imgHeight/2

                lineMsg = String()
                lineMsg.data = "left"
                self.pub_line.publish(lineMsg)

            elif followRight:
                leftLineX = rightLineX - imgWidth
                leftLineY = imgHeight/2

                lineMsg = String()
                lineMsg.data = "right"
                self.pub_line.publish(lineMsg)
            else:
                lineMsg = String()
                lineMsg.data = "both"
                self.pub_line.publish(lineMsg)

            
            rightLineX = int(rightLineX)
            rightLineY = int(rightLineY)

            leftLineX = int(leftLineX)
            leftLineY = int(leftLineY)

            goalX = int((rightLineX + leftLineX)/2)
            goalY = int((rightLineY + leftLineY)/2)

            originX, originY = [int(imgWidth/2),imgHeight]

            originX = int(originX)
            originY = int(originY)

            goalAngle = Float64()
            goalAngle.data = 90 - degrees(atan2( originY - goalY, originX - goalX ))
            self.pub_angle.publish(goalAngle)

            # print("goalAngle",goalAngle)
            # print(lineMsg.data)
            # print("wwwwwwwwwwwww")


            if True:
                I_warped_rgb = cv2.cvtColor(I_warped * 255, cv2.COLOR_GRAY2BGR)

                # Origin point
                I_res = cv2.circle(I_warped_rgb, (originX,originY), radius=50, color=(255, 0, 0), thickness=-1)
                # Goal point
                cv2.circle(I_res, (goalX,goalY), radius=50, color=(0, 255, 0), thickness=-1)
                # Left point
                cv2.circle(I_res, (leftLineX,leftLineY), radius=50, color=(255, 147, 0), thickness=-1)
                # Right point
                cv2.circle(I_res, (rightLineX,rightLineY), radius=50, color=(220, 0, 255), thickness=-1)
                # Arrow to goal
                cv2.arrowedLine(I_res, (originX,originY), (goalX,goalY), color=(0, 135, 255), thickness=2)

                I_res = cv2.cvtColor(I_res, cv2.COLOR_BGR2RGB)

                self.ImgShow("I_res", I_res)

            mainLoop.sleep()


    def ImgShow(self, figName, I, resize = True):
        if resize:
            Ires = cv2.resize(I, (int(I.shape[1]/3),int(I.shape[0]/3)))
            cv2.imshow(figName, Ires)
        else:
            cv2.imshow(figName, I)
        cv2.waitKey(50)
        pass


    def ConnectedComponents(self,I_warped):
        # Apply the Component analysis function
        analysis = cv2.connectedComponentsWithStats(I_warped, 4, cv2.CV_32S)
        (totalLabels, label_ids, values, centroid) = analysis
        
        # Initialize a new image to
        # store all the output components
        leftLineMask = np.zeros(I_warped.shape, dtype="uint8")
        rightLineMask = np.zeros(I_warped.shape, dtype="uint8")

        # Loop through each component
        for i in range(1, totalLabels):
            area = values[i, cv2.CC_STAT_AREA]

            if (area > 200):
                componentMask = (label_ids == i).astype("uint8") * 255

                points = np.where(componentMask == 255)
                
                x = max(points[1][:])
                if x >= I_warped.shape[0]:
                    rightLineMask = cv2.bitwise_or(rightLineMask, componentMask)
                else:
                    leftLineMask = cv2.bitwise_or(leftLineMask, componentMask)
        
        return leftLineMask, rightLineMask


if __name__ == '__main__':
    try:
        lineDetection = LineDetection()
        lineDetection.Start()
        print("\n\t... Line Detection EXITED ...\n")
    except rospy.ROSInterruptException:
        pass
