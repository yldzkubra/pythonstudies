#!/usr/bin/env python

import rospy, bisect
import math as mt
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from std_msgs.msg import Float64
from sensor_msgs.msg import LaserScan
from ismu_pkg.msg import EstimatedPose
from geometry_msgs.msg import TwistStamped


class Park():
    def __init__(self):
        self.data = []
        self.dis = 0
        self.goalx = 0
        self.goaly = 0
        self.statex = 0
        self.statey = 0
        self.statetheta = 0
        self.direk = []
        self.indis = []
        self.direklist = []
        self.indislist = []
        self.rx, self.ry, self.ryaw, self.rk = [], [], [], []

        self.currentSpeed = 0
        self.targetSpeed = 0

        # rospy.init_node('park_node', anonymous=True)
        rospy.Subscriber('/scan', LaserScan, self.laser_callback)
        rospy.Subscriber("/twist", TwistStamped, self.callbackCurrentSpeed)  
        rospy.Subscriber('ekf/estimated_pose',EstimatedPose,self.ekf_callback)
    

    def ParkManevrasi(self):
        self.goalplanner()

        print("goalx:", self.goalx,"    goaly:", self.goaly)
        print("statex:", self.statex," statey:", self.statey)

        pub_aci = rospy.Publisher('/steering_cmd',Float64,queue_size=10)
        str_msg = Float64()
        str_msg.data = 0.0
        pub_aci.publish(str_msg)

        x = [self.statex, self.statex + 2.5, self.goalx - 7.0, self.goalx]
        y = [self.statey, self.statey + 0.6, self.goaly - 0.7, self.goaly]

        """interval_point_x = self.goalx/3
        interval_point_y = self.goaly/2.2
        
        if interval_point_x > 1.5:
            interval_point_x = 1.5

        if interval_point_y > 7.5:
            interval_point_y = 7.5

        x = [self.statex, self.statex + interval_point_x, self.goalx + interval_point_x, self.goalx]
        y = [self.statey, self.statey - interval_point_y, self.goaly - interval_point_y, self.goaly]"""

        ds = 0.1  # [m] distance of each interpolated points

        sp = Spline2D(x, y)
        s = np.arange(0, sp.s[-1], ds)
        
        for i_s in s:
            ix, iy = sp.calc_position(i_s)
            self.rx.append(ix)
            self.ry.append(iy)
            self.ryaw.append(sp.calc_yaw(i_s))
            self.rk.append(sp.calc_curvature(i_s))

        plt.subplots(1)
        plt.plot(x, y, "xb", label="input")
        plt.plot(self.rx, self.ry, "-r", label="spline")
        plt.grid(True)
        plt.axis("equal")
        plt.xlabel("x[m]")
        plt.ylabel("y[m]")
        plt.legend()
        plt.show(block=False)
        plt.pause(3)
        plt.close()
        self.movetopose()


    def movetopose(self):
        cx = self.rx  # x points of path (spline) 
        cy = self.ry  # y points of path (spline) 

        len_path = max(len(cx), len(cy)) 
        limit = 4

        speed_k = 0.1  # speed gain (Kp_speed)
        gamma_k = 9.5  # gamma gain (Kp_gamma)
        rate = rospy.Rate(10)  # sleep 0.1s

        speed_msg = Float64()
        steer_msg = Float64()
        brake_msg = Float64() 
        pub_speed = rospy.Publisher('/throttle_cmd',Float64,queue_size=10)
        pub_steer = rospy.Publisher('/steering_cmd',Float64,queue_size=10)
        pub_brake = rospy.Publisher('/brake_cmd',Float64,queue_size=10)

        """
        Go to Goal

        while 1:
            goalx = 10.0
            goaly = 20.0

            self.targetSpeed = speed_k * mt.sqrt((goalx - self.statex)**2 + (goaly - self.statey)**2)  # calculate speed
            if self.targetSpeed > 0.5:
                self.targetSpeed = 0.5

            speed = self.calculateSpeed()

            theta = mt.atan2(goaly - self.statey, goalx - self.statex)  # calculate target angle
            errortheta = mt.atan2(mt.sin(theta - self.statetheta), mt.cos(theta - self.statetheta))  # calculate error angle between heading and target angle
            gamma = gamma_k * errortheta  # calculate steer
            #gamma = errortheta

            dist_to_goal = mt.sqrt((goalx - self.statex)**2 + (goaly - self.statey)**2)  # distance between car and goal (park point)
            if dist_to_goal < 1.0:
                brake_msg.data = 800
                speed = 0
                pub_brake.publish(brake_msg)  # stop when distance between car and goal is 1.0

            speed_msg.data = speed
            pub_speed.publish(speed_msg)
            steer_msg.data = gamma
            pub_steer.publish(steer_msg)
            """

        while limit < len_path:

            headx = cx[limit]  # target x point in path (spline)
            heady = cy[limit]  # target y point in path (spline)

            self.targetSpeed = speed_k * mt.sqrt((self.goalx - self.statex)**2 + (self.goaly - self.statey)**2)  # calculate speed
            if self.targetSpeed > 1.0:
                self.targetSpeed = 1.0

            if self.targetSpeed < 0.3 and self.targetSpeed != 0:
                self.targetSpeed = 0.3

            speed = self.calculateSpeed()

            theta = mt.atan2(heady - self.statey, headx - self.statex)  # calculate target angle
            errortheta = mt.atan2(mt.sin(theta - self.statetheta), mt.cos(theta - self.statetheta))  # calculate error angle between heading and target angle
            gamma = gamma_k * errortheta  # calculate steer

            if limit < 6:  # slowly start move
                speed = 0.3
            
            rate.sleep()

            dist_to_target = mt.sqrt((headx - self.statex)**2 + (heady - self.statey)**2)  # distance between car and target point
            if dist_to_target < 0.5:
                limit += 2  # change target point when distance between car and target point is 0.5
        
            dist_to_goal = mt.sqrt((self.goalx - self.statex)**2 + (self.goaly - self.statey)**2)  # distance between car and goal (park point)
            if dist_to_goal < 0.5:
                brake_msg.data = 800
                speed = 0
                pub_brake.publish(brake_msg)  # stop when distance between car and goal is 0.5

            speed_msg.data = speed
            pub_speed.publish(speed_msg)
            steer_msg.data = gamma
            pub_steer.publish(steer_msg)

    # FIND GOAL
    def goalplanner(self):
        # gelen trafik tabelasina bak sagdan sola siralanmis data
        # bu yaklasim araba dik girerse gecerli park alanina

        trafiktabela = ['yasak','yasak','serbest','serbest','yasak','yasak','yasak']
        counter = 0
        tabela1 = 0
        tabela2 = 0

        print("direklist:",self.direklist)
        print("indislist:",self.indislist)
        
        if len(trafiktabela)!=len(self.direklist):
            print("lidar-camera datalar uyusmuyor!!")
        
        # MUSAIT (YANYANA) IKI PARK DIREGININ BULUNMASI
        for i in range(len(trafiktabela)):
            if trafiktabela[i] == 'serbest':
                if counter == 0:
                    tabela1 = self.direklist[i]
                    counter = counter + 1
                elif counter == 1:
                    tabela2 = self.direklist[i]
                    break

        # IKI DIREK UZERINDEN HEDEF KONUMUN BELIRLENMESI
        a = (tabela2**2 - tabela1**2 - 2.5**2) / 5
        h = mt.sqrt(tabela1**2 - a**2)
        # print("a:", a,"h:", h,"tabela2:", tabela2, "tabela1:", tabela1)

        self.goalx = self.statex + h - 1.0
        self.goaly = self.statey + a + 0.5

    # CALCULATE TRACKING SPEED
    def calculateSpeed(self):  # calculate constant (appropriate) speed
        vel_Kp = 1.3
        brake_Kp = 5e2
        speedError = self.targetSpeed - self.currentSpeed
        if (self.targetSpeed > 0 and speedError > 0) or (self.targetSpeed < 0 and speedError < 0):
            throttle = abs(speedError * vel_Kp)
            return throttle
        else:
            brake = Float64()
            brake.data = brake_Kp * abs(speedError)
            pub_brake = rospy.Publisher('/brake_cmd',Float64,queue_size=10)
            brake = pub_brake.publish(brake)
            return 0

    def calc_spline_course(x, y, ds=0.1):
        sp = Spline2D(x, y)
        s = list(np.arange(0, sp.s[-1], ds))

        rx, ry, ryaw, rk = [], [], [], []
        for i_s in s:
            ix, iy = sp.calc_position(i_s)
            rx.append(ix)
            ry.append(iy)
            ryaw.append(sp.calc_yaw(i_s))
            rk.append(sp.calc_curvature(i_s))

        return rx, ry, ryaw, rk, s

    def callbackCurrentSpeed(self, speed_msg):
        self.currentSpeed = round(speed_msg.twist.linear.x, 2)

    def ekf_callback(self, kalman_msg):
        self.statex = kalman_msg.x 
        self.statey = kalman_msg.y 
        self.statetheta = kalman_msg.heading
        #print("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww")
        #print("statex:",self.statex,"statey:",self.statey)
        #print("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww")

    def laser_callback(self, laser_msg):
        self.data = laser_msg.ranges
        inf = np.nan
        readeddata = {'dist' : self.data}
        self.dis = pd.DataFrame(readeddata)
        self.dis = self.dis.dropna()
        self.dis.to_csv('veri.csv')

        for i in range(self.dis['dist'].size-1):
            if i>2 and self.dis['dist'].size-2>i:
                if (self.dis['dist'][i]-self.dis['dist'][i-1])>0.3 and (self.dis['dist'][i+1]-self.dis['dist'][i])>0.3 :
                    #print("dont care condi")
                    pass
                elif (self.dis['dist'][i]-self.dis['dist'][i-1])<-0.3 and (self.dis['dist'][i]-self.dis['dist'][i+1])<-0.3:
                    self.indis.append(i)
                    #print(indis)
                elif (self.dis['dist'][i]-self.dis['dist'][i-1])<-0.3 and abs(self.dis['dist'][i]-self.dis['dist'][i+1])<0.1:
                    self.indis.append(i)
                    #print(indis)
                else:
                    #print("duzduvar")
                    pass
        
        for i in range(len(self.indis)):
            self.direk.append(self.dis['dist'][self.indis[i]])
            #print(self.direk)
            #print(self.indis)

        self.direklist = self.direk
        self.indislist = self.indis
        self.indis = []
        self.direk = []


class Spline:
    """
    Cubic Spline class
    """

    def __init__(self, x, y):
        self.b, self.c, self.d, self.w = [], [], [], []

        self.x = x
        self.y = y

        self.nx = len(x)  # dimension of x
        h = np.diff(x)

        # calc coefficient c
        self.a = [iy for iy in y]

        # calc coefficient c
        A = self.__calc_A(h)
        B = self.__calc_B(h)
        self.c = np.linalg.solve(A, B)
        #  print(self.c1)

        # calc spline coefficient b and d
        for i in range(self.nx - 1):
            self.d.append((self.c[i + 1] - self.c[i]) / (3.0 * h[i]))
            tb = (self.a[i + 1] - self.a[i]) / h[i] - h[i] * (self.c[i + 1] + 2.0 * self.c[i]) / 3.0
            self.b.append(tb)

    def calc(self, t):
        """
        Calc position
        if t is outside of the input x, return None
        """

        if t < self.x[0]:
            return None
        elif t > self.x[-1]:
            return None

        i = self.__search_index(t)
        dx = t - self.x[i]
        result = self.a[i] + self.b[i] * dx + self.c[i] * dx ** 2.0 + self.d[i] * dx ** 3.0

        return result

    def calcd(self, t):
        """
        Calc first derivative
        if t is outside of the input x, return None
        """

        if t < self.x[0]:
            return None
        elif t > self.x[-1]:
            return None

        i = self.__search_index(t)
        dx = t - self.x[i]
        result = self.b[i] + 2.0 * self.c[i] * dx + 3.0 * self.d[i] * dx ** 2.0
        return result

    def calcdd(self, t):
        """
        Calc second derivative
        """

        if t < self.x[0]:
            return None
        elif t > self.x[-1]:
            return None

        i = self.__search_index(t)
        dx = t - self.x[i]
        result = 2.0 * self.c[i] + 6.0 * self.d[i] * dx
        return result

    def __search_index(self, x):
        """
        search data segment index
        """
        return bisect.bisect(self.x, x) - 1

    def __calc_A(self, h):
        """
        calc matrix A for spline coefficient c
        """
        A = np.zeros((self.nx, self.nx))
        A[0, 0] = 1.0
        for i in range(self.nx - 1):
            if i != (self.nx - 2):
                A[i + 1, i + 1] = 2.0 * (h[i] + h[i + 1])
            A[i + 1, i] = h[i]
            A[i, i + 1] = h[i]

        A[0, 1] = 0.0
        A[self.nx - 1, self.nx - 2] = 0.0
        A[self.nx - 1, self.nx - 1] = 1.0
        #  print(A)
        return A

    def __calc_B(self, h):
        """
        calc matrix B for spline coefficient c
        """
        B = np.zeros(self.nx)
        for i in range(self.nx - 2):
            B[i + 1] = 3.0 * (self.a[i + 2] - self.a[i + 1]) / h[i + 1] - 3.0 * (self.a[i + 1] - self.a[i]) / h[i]
        return B


class Spline2D:
    """
    2D Cubic Spline class
    """

    def __init__(self, x, y):
        self.s = self.__calc_s(x, y)
        self.sx = Spline(self.s, x)
        self.sy = Spline(self.s, y)

    def __calc_s(self, x, y):
        dx = np.diff(x)
        dy = np.diff(y)
        self.ds = np.hypot(dx, dy)
        s = [0]
        s.extend(np.cumsum(self.ds))
        return s

    def calc_position(self, s):
        """
        calc position
        """
        x = self.sx.calc(s)
        y = self.sy.calc(s)

        return x, y

    def calc_curvature(self, s):
        """
        calc curvature
        """
        dx = self.sx.calcd(s)
        ddx = self.sx.calcdd(s)
        dy = self.sy.calcd(s)
        ddy = self.sy.calcdd(s)
        k = (ddy * dx - ddx * dy) / ((dx ** 2 + dy ** 2)**(3 / 2))
        return k

    def calc_yaw(self, s):
        """
        calc yaw
        """
        dx = self.sx.calcd(s)
        dy = self.sy.calcd(s)
        yaw = mt.atan2(dy, dx)
        return yaw


if __name__ == '__main__':
	try:
		keepit = Park()
	except rospy.ROSInterruptException: pass
