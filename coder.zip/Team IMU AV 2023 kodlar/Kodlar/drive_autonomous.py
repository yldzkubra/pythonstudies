#!/usr/bin/env python

import rospy, enum
from std_msgs.msg import UInt8,Float64, Bool, String, Float64MultiArray
from geometry_msgs.msg import TwistStamped



class Drive():

    class STATES(enum.Enum):
        LINE_FOLLOW = 0
        TURN_LEFT = 1
        TURN_RIGHT = 2
        RED = 3
        GREEN = 4
        BUS = 5
        OBSTACLE_AVOIDANCE = 6
        PARK = 7


    def __init__(self):
        self.goalAngle = 0
        self.steeringAngle = 0
        self.curSpeed = 0
        self.obstacle = False

        self.isTeleopActive = False
        self.isMotorStarted = False
        self.motorState = False

        self.redState = False
        self.redFlag = False
        self.redCount = 0

        self.obsNumber = 0
        self.counter = 0
        self.number=0

        self.line = "none"
        
        self.leftDist = 40
        self.frontDist = 40
        self.rightDist = 40

        self.obsAvoDist_Sides = 0.7 # m
        self.obsAvoDist_Front = 3.2 # m
        self.obsAvoDist_LeftFront = 3 # m
        
        self.sideFollowDist = 1.2 # m
        self.cancelFollowDist = 5 # m

        self.speed = 30

        self.state = Drive.STATES.LINE_FOLLOW

    


        rospy.init_node('drive_node', anonymous=False)
        rospy.Subscriber("/line_detection/goal_angle", Float64, self.cb_GoalAngle)
        rospy.Subscriber("/twist", TwistStamped, self.cb_Twist)
        rospy.Subscriber("/line_detection/lines", String, self.cb_Line)
        rospy.Subscriber("/teleop/active", Bool, self.cb_Teleop)
        rospy.Subscriber("/obstacle/is_obstacle_detected", Bool, self.cb_Obstacle)
        rospy.Subscriber("/obstacle/distances", Float64MultiArray, self.cb_ObsDistances)
        #rospy.Subscriber("/detect_red/isDetected", Bool, self.cb_RedLight)

        self.pub_angle = rospy.Publisher('/line_detection/goal_angle', Float64, queue_size=1)
        self.pub_steering = rospy.Publisher("/steering_cmd_smach", Float64, queue_size=1)
        self.pub_throttle = rospy.Publisher("/throttle_cmd_smach", Float64, queue_size=1)
        self.pub_gear = rospy.Publisher("/gear_cmd", UInt8, queue_size=1)
        self.pub_brake = rospy.Publisher("/brake_cmd_smach", Float64, queue_size=1)
        self.pub_signal = rospy.Publisher("/signal_cmd", UInt8, queue_size=1)
        self.pub_counter = rospy.Publisher("/park",UInt8, queue_size=1)

        rospy.Timer(rospy.Duration(1.0/5.0), self.PubThrStrThread, oneshot=False)

        print("\n\t... Drive Started ...\n")
        pass


    def PubThrStrThread(self, event):
        if self.motorState and not self.obstacle:
            if not self.isMotorStarted:
                self.isMotorStarted = True
                self.PubBrake(False)
                self.PubThrottle(70)
                rospy.sleep(0.5)
                self.PubThrottle(self.speed)

            else:
                self.PubBrake(False)
                self.PubThrottle(self.speed)
        else:
            self.isMotorStarted = False
            self.PubThrottle(0)
            self.PubBrake(True)

        self.PubSteering(self.steeringAngle)

        if self.redFlag:
            self.redCount += 1
            if self.redCount > 5 * 90: # 1.30 min
                self.redFlag = False
        pass


    def cb_ObsDistances(self,msg):
        self.obsDistances = msg.data
        self.leftDist = msg.data[0]
        self.frontDist = msg.data[1]
        # self.rightDist = msg.data[2]
        self.rightDist = msg.data[5]

        # if self.rightDist > 8:
        #     self.state = Drive.STATES.PARK

        # if self.frontDist < self.obsAvoDist_Front and self.number == 0:
        #     self.state = Drive.STATES.OBSTACLE_AVOIDANCE
        #     self.obsNumber = 1
        #     self.number=1
            
           
        if self.frontDist < self.obsAvoDist_Front :
            self.state = Drive.STATES.OBSTACLE_AVOIDANCE
            self.obsNumber = 2
            

            
        pass


    def cb_Obstacle(self,msg):
        self.obstacle = msg.data
        pass


    def cb_Line(self,msg):
        self.line = msg.data
        pass


    def cb_Teleop(self,msg):
        self.isTeleopActive = msg.data
        pass


    def cb_GoalAngle(self,msg):
        self.goalAngle = msg.data
        pass


    def cb_Twist(self,msg):
        self.curSpeed = msg.twist.linear.x
        pass


    def PubSteering(self,angle):
        msg = Float64()
        msg.data = angle
        self.pub_steering.publish(msg)
        pass


    def PubSignal(self,signal):
        if signal == "c": # close
            val = 0
        if signal == "l": # left
            val = 1
        elif signal == "r": # right
            val = 2
        elif signal == "b": # both
            val = 3

        msg = UInt8()
        msg.data = val
        self.pub_signal.publish(msg)
        pass


    def PubBrake(self,boolBrake):
        msg = Float64()
        if boolBrake:
            msg.data = 180
            self.pub_brake.publish(msg)
        else:
            msg.data = 0
            self.pub_brake.publish(msg)
        pass


    def PubThrottle(self,throttle):
        msg = Float64()
        msg.data = throttle
        self.pub_throttle.publish(msg)
        pass


    def Start(self):
        for i in range(5):
            self.PubSteering(0)
            self.PubBrake(False)
            rospy.sleep(0.2)

        self.PubSignal("c")

        loopRate = rospy.Rate(5)
        while not rospy.is_shutdown():

            if self.state == Drive.STATES.LINE_FOLLOW:
                self.motorState = True

                self.steeringAngle = self.CalcAngle(self.goalAngle)

            elif self.state == Drive.STATES.TURN_LEFT:
                pass

            elif self.state == Drive.STATES.TURN_RIGHT:
                pass

            elif self.state == Drive.STATES.RED:
                loopRate = rospy.Rate(5)
                count = 0
                while not rospy.is_shutdown() and self.redState and not self.redFlag:
                    print("Red")
                    self.motorState = False
                    self.PubBrake(180)
                    
                    count += 1
                    if count > 5 * 30:
                        self.redFlag = True
                        break
                    loopRate.sleep()
                
                self.state = Drive.STATES.LINE_FOLLOW
                self.PubBrake(0)
                self.motorState = True
                pass

            elif self.state == Drive.STATES.GREEN:
                self.state = Drive.STATES.LINE_FOLLOW
                pass

            elif self.state == Drive.STATES.BUS:
                # self.BusStop()
                self.state = Drive.STATES.LINE_FOLLOW
                pass

            elif self.state == Drive.STATES.OBSTACLE_AVOIDANCE:
                if self.obsNumber == 1:
                    self.ObsAvoidLeft()
                    

                elif self.obsNumber == 2:
                    self.ObsAvoidFront()
                    self.counter += 1
                    
                    if self.counter == 3 :
                       self.pub_counter.publish(self.counter)
                       
                       
                       

                self.state = Drive.STATES.LINE_FOLLOW

            elif self.state == Drive.STATES.PARK:
                self.PubBrake(0)
                self.motorState = True
                self.steeringAngle = 0
                rospy.sleep(3)
                self.steeringAngle = -45
                rospy.sleep(4)
                self.state = Drive.STATES.LINE_FOLLOW

            print("Motor State {}".format(self.motorState))
            print("Line: {}".format(self.line))
            print("Steering angle: {}".format(self.steeringAngle))
            print(self.state)
            print("wwwwwwwwww")
            loopRate.sleep()
            pass


    def ObsAvoidLeft(self):
        angle = 30

        print("\nLeft Obstacle Avoidance\n")
        print("right")
        self.steeringAngle = -angle
        self.PubSignal("r")
        rospy.sleep(3.5)

        print("right")
        self.steeringAngle = 0
        rospy.sleep(2)

        print("left")
        self.steeringAngle = angle
        rospy.sleep(2.5)

        self.PubSignal("c")
        print("\nObstacle Avoidance Finished\n")
        pass


    def ObsAvoidFront(self):
        angle = 40

        print("\nRight Obstacle Avoidance\n")
        print("left")
        self.PubSignal("l")
        self.steeringAngle = angle
        rospy.sleep(3.5)

        self.steeringAngle = 0
        rospy.sleep(1)

        print("right")
        self.steeringAngle = -angle
        rospy.sleep(3.5)

        # wwwwwwwwwwwwww
        print("right")
        self.PubSignal("c")
        self.steeringAngle = 0
        rospy.sleep(1)
        # wwwwwwwwwwwwww

        print("right")
        self.PubSignal("r")
        self.steeringAngle = -angle
        rospy.sleep(3)

        self.steeringAngle = 0
        rospy.sleep(1)

        print("left")
        self.steeringAngle = angle
        rospy.sleep(3)

        self.PubSignal("c")
        print("\nObstacle Avoidance Finished\n")
        pass


    def BusStop(self):
        inTime = 3.5 # second turn right, get in to the bus stop
        turnLeft = 4 # second turn left
        stayYime = 5 # second stay steady
        outTime = 5 # second turn left, leave the bus stop
        turnRight = 4 # second turn left

        turnLeftAngle = 40
        turnRigthAngle = 50
        
        self.motorState = True
        self.steeringAngle = 0
        rospy.sleep(4)
        
        print("Bus Stop Started")
        # turn right
        print("turn right 1")
        self.PubSignal("r")
        self.motorState = True
        self.steeringAngle = -turnRigthAngle
        rospy.sleep(inTime)

        # turn left
        print("turn left 1")
        self.motorState = True
        self.steeringAngle = turnLeftAngle
        rospy.sleep(turnLeft)

        # stay steady
        print("stay steady 1")
        self.PubSignal("c")
        self.motorState = False
        rospy.sleep(stayYime)

        # turn left
        print("turn left 2")
        self.PubSignal("l")
        self.motorState = True
        self.steeringAngle = turnLeftAngle
        rospy.sleep(outTime)

        # turn right
        print("turn right 2")
        self.motorState = True
        self.steeringAngle = -turnRigthAngle
        rospy.sleep(turnRight)

        self.PubSignal("c")
        self.steeringAngle = 0

        print("Bus Stop Finished")
        pass


    def CalcAngle(self, angle):
        limit = 45
        if angle >= limit:
            angle = limit
        
        if angle <= -limit:
            angle = -limit

        if self.line == "none":
            Kp = 1
            # angle = -10
        elif self.line=="left":
            Kp = 0.8
        elif self.line=="right":
            Kp = 1
        elif self.line == "both":
            Kp = 0.6

        return angle * Kp



if __name__ == '__main__':
    try:
        drive = Drive()
        drive.Start()
        print("\n\t... Drive EXITED ...\n")
    except rospy.ROSInterruptException:
        pass