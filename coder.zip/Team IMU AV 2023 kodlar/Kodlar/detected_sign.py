#!/usr/bin/env python

'''
Kübra Yildiz / kubrayildi61@gmail.com
12 Nisan 2023
'''

import threading
import rospy, enum
from std_msgs.msg import String, Int32, Float64MultiArray
from geometry_msgs.msg import PointStamped


class SignDetection:
    def __init__(self):
         rospy.init_node('object_detection',anonymous=True)
         self.object_area_subscriber= rospy.Subscriber('/object_area', PointStamped, queue_size=10)
         self.pub_traffic_sign = rospy.Publisher('/object_detection/detected_sign', String, queue_size=1)
         
    
         self.area_threshold = 10e3
         self.durak_area_treshhold = 4400
         self.park_area_treshhold = 340
         self.stop_area_treshhold = 46000
         self.trafik_kirmizi_treshhold = 3100
         self.flag_park = 0

         print("\n\t... detected_sign started ...\n")
         rospy.spin()

    class Sign(enum.Enum):
        GIRILMEZ_YOL = 0
        SOLA_DONULMEZ = 1
        SAGA_DONULMEZ = 2
        ILERIDEN_SOLA_MECBBURI = 3
        ILERIDEN_SAGA_MECBURI = 4
        DUR = 5
        PARK_YERI = 6
        PARK_EDILMEZ = 7
        DURAK = 8
        ILERI_VE_SOLA_MECBURI = 9
        ILERI_VE_SAGA_MECBURI = 10
        TRAFIK_LAMBASI_YESIL = 11
        TRAFIK_LAMBASI_KIRMIZI = 12
        TRAFIK_LAMBASI_SARI = 13
        ENGELLI_PARK_YERI = 14
        DONEL_KAVSAK = 15
        YOK = 16
        

    def cb_ObsDistances(self,msg):
        self.obsDistances = msg.data


    def callback(self,data):
        self.box=data.bounding_boxes
        liste=[]
        listem=[[],[],[]]

        readSign = ""
        
        for box in self.box:
            height=box.ymax-box.ymin
            width=box.xmax-box.xmin
            area=height*width
            listem[0].append(box.Class)
            listem[1].append(box.probability)
            listem[2].append(area)

            liste.append(area)
            liste.sort(reverse=True)

            if area > self.durak_area_treshhold and area < 4700 and SignDetection.Sign.DURAK.name == box.Class :
                    
                readSign = box.Class
                    

            elif area > self.park_area_treshhold and  area < 555 and SignDetection.Sign.PARK_YERI.name == box.Class:
                if self.flag_park == 0:
                    readSign = box.Class
                    self.flag_park += 1


            elif area > 40000 and area < 50000 and SignDetection.Sign.DUR.name == box.Class:
                readSign = box.Class
                

            elif area > self.trafik_kirmizi_treshhold and area < 3500 and SignDetection.Sign.TRAFIK_LAMBASI_KIRMIZI.name == box.Class:
                readSign = box.Class

            elif area > self.area_threshold:
                #if SignDetection.Sign.DURAK.name == box.Class:
                #    readSign = box.Class
                    #print("box class is", box.Class)
                #     break
                #else:
                  if  SignDetection.Sign.DURAK.name != box.Class and SignDetection.Sign.PARK_YERI.name != box.Class and SignDetection.Sign.DUR.name != box.Class and SignDetection.Sign.TRAFIK_LAMBASI_KIRMIZI.name != box.Class:
                    readSign = box.Class
                    print("box class is-----------", box.Class)
                  else:
                    readSign = SignDetection.Sign.YOK.name

                    
            else:
                readSign = SignDetection.Sign.YOK.name


            signMsg = String()
            signMsg.data = readSign

            self.pub_traffic_sign.publish(signMsg)
            
            
if __name__== '__main__':
    try:
        x=SignDetection()
    except rospy.ROSInterruptException:
        pass
