import cv2 

algorithm = input("kullanmak istediğiniz algoritmayı giriniz: ").strip().lower()


video = cv2.VideoCapture("videos/test_1.mp4")
ret, frame = video.read()

if not ret:
    print("video başarılı bir şekilde okunamadı!")
    exit()

# ROI -> Region of Interest  (İlgi Alanı)
bbox = cv2.selectROI(frame, False)


if algorithm == "csrt":
    tracker = cv2.legacy.TrackerCSRT_create()

elif algorithm == "kcf":
    tracker = cv2.legacy.TrackerKCF_create()

elif algorithm == "mil":
    tracker = cv2.legacy.TrackerMIL_create()

elif algorithm == "tld":
    tracker = cv2.legacy.TrackerTLD_create()

elif algorithm == "medianflow":
    tracker = cv2.legacy.TrackerMedianFlow_create()

elif algorithm == "mosse":
    tracker = cv2.legacy.TrackerMOSSE_create()

elif algorithm == "boosting":
    tracker = cv2.legacy.TrackerBoosting_create()

else:
    print("geçersiz bir algoritma girildi!")
    video.release()
    cv2.destroyAllWindows()
    exit()

tracker.init(frame, bbox)


while True:
    ret, frame = video.read()

    if not ret:
        break 

    success, bbox = tracker.update(frame)
    "bbox ->   x,y,w,h"
    if success:
        p1 = (int(bbox[0]), int(bbox[1]))
        p2 = (int(bbox[0]) + int(bbox[2]), int(bbox[1]) +int(bbox[3]))

        cv2.rectangle(frame, p1, p2, (0,255,0), 2)
    
    else:
        print("takip başarısız")

    cv2.imshow("frame", frame)

    if cv2.waitKey(10) & 0xFF == ord("q"):
        break 

video.release()
cv2.destroyAllWindows()




