#!/usr/bin/env python

'''
Enes Kirimli / enes1kirimli@gmail.com
Emirhan Gürsoy / emirhangursoy13@gmail.com
12 Nisan 2023
'''

import rospy
import enum
import smach
import smach_ros , time
from std_msgs.msg import  Int32, Float64, String, UInt8

# STATE CLASSES
class SIGN(enum.Enum):
    DUR = 0
    DURAK = 1
    TRAFIK_LAMBASI_KIRMIZI = 2
    PARK_YERI = 3

class LineFollow(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['park',
                                             'red_light',
                                             'bus',
                                             'stop',
                                             'finished',
                                             'turn_back'])
        
        rospy.Subscriber('/idle_msg',Int32 ,self.callback_idle)
        rospy.Subscriber('/object_detection/detected_sign', String, self.callback_sign_msg)
        
        rospy.Subscriber("/steering_cmd_smach", Float64, self.callback_steering)
        rospy.Subscriber("/throttle_cmd_smach", Float64, self.callback_throttle)
        rospy.Subscriber("/brake_cmd_smach", Float64, self.callback_brake)

        rospy.Subscriber("/park",UInt8,self.callback_park)

        self.pub_steering = rospy.Publisher("/steering_cmd", Float64, queue_size=1)
        self.pub_throttle = rospy.Publisher("/throttle_cmd", Float64, queue_size=1)
        self.pub_brake = rospy.Publisher("/brake_cmd", Float64, queue_size=1)
        self.pub_signal = rospy.Publisher("/signal_cmd", UInt8, queue_size=1)

        self.idle_msg = Int32(0)
        self.sign_msg = String()
        

        self.parkflag=0
        

    def callback_idle (self,user_data):
        self.idle_msg=user_data
    
    def callback_sign_msg (self,user_data):
        self.sign_msg = String()
        self.sign_msg = user_data.data

    def callback_steering(self,msg):
        self.steering_msg = Float64(0)
        self.steering_msg = msg.data

    def callback_throttle(self,msg):
        self.throttle_msg = Float64(0)
        self.throttle_msg = msg.data

    def callback_brake(self,msg):
        self.brake_msg = Float64(0)
        self.brake_msg = msg.data

    
    
    


    def execute(self,user_data):
        rospy.loginfo("Running Line Follow State...")

        
        
        self.pub_steering.publish(self.steering_msg) 
        rospy.sleep(0.1)
        self.pub_throttle.publish(self.throttle_msg)
        self.pub_brake.publish(self.brake_msg)
        
        
        if self.sign_msg == SIGN.DUR.name:
            return 'stop'
        
        elif self.sign_msg == SIGN.DURAK.name:
            return 'bus'

        elif self.sign_msg == SIGN.TRAFIK_LAMBASI_KIRMIZI.name:
            return 'red_light'

        elif self.sign_msg == SIGN.PARK_YERI.name:
            return 'park'
        
        elif self.idle_msg.data == 1:
            self.pub_brake.publish(180)
            return 'finished'

        else:
            return 'turn_back'

class Idle(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['started','turn_back'])
        rospy.Subscriber('idle_msg',Int32 ,self.callback_idle)
        self.idle_msg = Int32(1)
        
    def callback_idle (self,user_data):
        self.idle_msg=user_data
    
    def execute(self,user_data):
        rospy.loginfo("Running Idle State...")
        rospy.sleep(1)
        
        if self.idle_msg.data == 1:
            return 'turn_back'
        else :
            return 'started'


class Park(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['succeed'])
        rospy.Subscriber('/object_detection/detected_sign', String, self.callback_sign_msg)
        rospy.Subscriber("/steering_cmd_smach", Float64, self.callback_steering)
        rospy.Subscriber("/throttle_cmd_smach", Float64, self.callback_throttle)
        rospy.Subscriber("/brake_cmd_smach", Float64, self.callback_brake)
        


        self.pub_steering = rospy.Publisher("/steering_cmd", Float64, queue_size=1)
        self.pub_throttle = rospy.Publisher("/throttle_cmd", Float64, queue_size=1)
        self.pub_brake = rospy.Publisher("/brake_cmd", Float64, queue_size=1)
        self.PubSignal = rospy.Publisher("/signal_cmd", UInt8, queue_size=1)
        
        self.sign_msg = String()
    
    def callback_sign_msg (self,user_data):
        self.sign_msg = String()
        self.sign_msg = user_data.data

    def callback_throttle(self,msg):
        self.throttle_msg = Float64(0)
        self.throttle_msg = msg.data

    def callback_steering(self,msg):
        self.steering_msg = Float64(0)
        self.steering_msg = msg.data

    def callback_brake(self,msg):
        self.brake_msg = Float64(0)
        self.brake_msg = msg.data
    
    def execute(self,user_data):
        rospy.loginfo("Running PARK State...")
        
        self.pub_throttle.publish(70)

        start_time = time.time()

        while (time.time() - start_time) < 19:
             self.pub_throttle.publish(30)
             time.sleep(0.1)
             self.pub_steering.publish(self.steering_msg)
        
        start_time = time.time()
        
        self.pub_throttle.publish(70)
        self.pub_steering.publish(-40)
        rospy.sleep(0.1)
        self.pub_throttle.publish(70)
        
        while (time.time() - start_time) < 4:
             self.pub_throttle.publish(30)
             time.sleep(0.1)

        start_time = time.time()

        self.pub_throttle.publish(70)
        self.pub_steering.publish(0)
        rospy.sleep(0.1)
        


        while (time.time() - start_time) < 6:
             self.pub_throttle.publish(30)
             time.sleep(0.1)
        self.park_msg = 0
        return 'succeed'

class RedLight(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['succeed','turn_back'])
        rospy.Subscriber('/object_detection/detected_sign', String, self.callback_sign_msg)
        self.sign_msg = String()

        self.pub_brake = rospy.Publisher("/brake_cmd", Float64, queue_size=1)

    def callback_sign_msg (self,user_data):
        self.sign_msg = String()
        self.sign_msg = user_data.data
    
    def execute(self,user_data):
        rospy.loginfo("Running RED_LIGHT State...")
        
        self.pub_brake.publish(180)
        


        if self.sign_msg == SIGN.TRAFIK_LAMBASI_KIRMIZI.name:
            return 'turn_back'
        else :
            return 'succeed'



class Bus(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['succeed'])
        rospy.Subscriber('/object_detection/detected_sign', String, self.callback_sign_msg)
        self.sign_msg = String()

        self.pub_steering = rospy.Publisher("/steering_cmd", Float64, queue_size=1)
        self.pub_throttle = rospy.Publisher("/throttle_cmd", Float64, queue_size=1)
        self.pub_brake = rospy.Publisher("/brake_cmd", Float64, queue_size=1)
        self.PubSignal = rospy.Publisher("/signal_cmd", UInt8, queue_size=1)
        rospy.Subscriber("/throttle_cmd_smach", Float64, self.callback_throttle)

    def callback_throttle(self,msg):
        self.throttle_msg = Float64(0)
        self.throttle_msg = msg.data

    def callback_sign_msg (self,user_data):
        self.sign_msg = String()
        self.sign_msg = user_data.data
    
    def execute(self,user_data):
        rospy.loginfo("Running BUS State...")
        inTime = 3.35 # first turn right, get in to the bus stop
        turnLeft = 4.4 # first turn left
        stayYime = 35 # second stay steady
        outTime = 4.5 # second turn left, leave the bus stop
        turnRight = 3.45 # second turn left
        lastTime = 0.3 # exit time

        turnLeftAngle = 40
        turnRigthAngle = 40
        start_time = time.time()

        self.motorState = True
        self.steeringAngle = 0
        
        self.pub_throttle.publish(70)
        print("Bus Stop Started")
        # turn right
        print("turn right 1")
        self.PubSignal.publish(2)
        self.motorState = True
        
        self.steeringAngle = -turnRigthAngle
        
        self.pub_steering.publish(self.steeringAngle)
        while (time.time() - start_time) < inTime:
             self.pub_throttle.publish(30)
             time.sleep(0.1)
        self.pub_throttle.publish(70)
        # turn left
        print("turn left 1")
        self.motorState = True
        self.steeringAngle = turnLeftAngle
        
        self.pub_steering.publish(self.steeringAngle)
        start_time = time.time()
        while (time.time() - start_time) < turnLeft:
             self.pub_throttle.publish(30)
             time.sleep(0.1)

        # stay steady
        print("stay steady 1")
        self.PubSignal.publish(0)
        
        self.motorState = False
        self.pub_brake.publish(180)
        rospy.sleep(stayYime)
        self.pub_brake.publish(0)
        self.pub_throttle.publish(70)

        # turn left
        print("turn left 2")
        self.PubSignal.publish(1)
        self.motorState = True
        
        self.steeringAngle = turnLeftAngle
        start_time = time.time()
        self.pub_steering.publish(self.steeringAngle)
        while (time.time() - start_time) < outTime:
             self.pub_throttle.publish(30)
             time.sleep(0.1)
        
        self.pub_throttle.publish(70)
        # turn right
        print("turn right 2")
        self.motorState = True
        
        self.steeringAngle = -turnRigthAngle
        
        self.pub_steering.publish(self.steeringAngle)
        start_time = time.time()
        while (time.time() - start_time) < turnRight:
             self.pub_throttle.publish(30)
             time.sleep(0.1)
        self.pub_throttle.publish(70)

        self.PubSignal.publish(0)
        
        self.steeringAngle = 0
        
        self.pub_steering.publish(self.steeringAngle)
        while (time.time() - start_time) < lastTime:
             self.pub_throttle.publish(30)
             time.sleep(0.1)

        print("Bus Stop Finished")
            
        return 'succeed'
    

class Stop(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes=['succeed'])
        rospy.Subscriber('/object_detection/detected_sign', String, self.callback_sign_msg)
        self.sign_msg = String()
        self.pub_brake = rospy.Publisher("/brake_cmd", Float64, queue_size=1)
        self.pub_throttle = rospy.Publisher("/throttle_cmd", Float64, queue_size=1)

    def callback_sign_msg (self,user_data):
        self.sign_msg = String()
        self.sign_msg = user_data.data
    
    def execute(self,user_data):
        rospy.loginfo("Running Stop State...")

        start_time = time.time()
        self.pub_brake.publish(180)
        rospy.sleep(5)
        self.pub_brake.publish(0)
        self.pub_throttle.publish(70)
        while (time.time() - start_time) < 2:
            self.pub_throttle.publish(50)
            time.sleep(0.1)
            
        return 'succeed'

def main():
    rospy.init_node("robotaksi_state_node")
    sm = smach.StateMachine(outcomes=[])
    with sm:
        smach.StateMachine.add('IDLE', Idle(),
                               transitions={'started':'LINE_FOLLOW',
                                            'turn_back':'IDLE'})
        smach.StateMachine.add('LINE_FOLLOW', LineFollow(),
                               transitions={'park':'PARK',
                                            'red_light':'RED_LIGHT',
                                            'bus':'BUS',
                                            'stop':'STOP',
                                            'finished':'IDLE',
                                            'turn_back':'LINE_FOLLOW'})
        smach.StateMachine.add('PARK', Park(),
                               transitions={'succeed':'LINE_FOLLOW',
                                            })
        smach.StateMachine.add('RED_LIGHT', RedLight(),
                               transitions={'succeed':'LINE_FOLLOW',
                                            'turn_back':'RED_LIGHT'})
        smach.StateMachine.add('BUS', Bus(),
                               transitions={'succeed':'LINE_FOLLOW',
                                            })
        smach.StateMachine.add('STOP', Stop(),
                               transitions={'succeed':'LINE_FOLLOW',
                                            })
    # Create and start the introspection server
    sis = smach_ros.IntrospectionServer('server_name', sm, '/ROBOTAKSI_SM')
    sis.start()

    # Execute the state machine
    outcome = sm.execute()

    # Wait for ctrl-c to stop the application
    rospy.spin()
    sis.stop()

if __name__ == '__main__':
    main()

