
# Verilen bir tamsayı dizisinde, lineer sürede ve sabit hafıza kullanarak eksik olan ilk pozitif tamsayıyı bulun. Başka bir deyişle, dizide bulunmayan en küçük pozitif tamsayıyı bulun. Dizi, tekrar eden ve negatif sayılar içerebilir.

# Örneğin, [3, 4, -1, 1] girdiğinde sonuç 2 olmalıdır. [1, 2, 0] girdiğinde sonuç 3 olmalıdır.



#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def first_missing_positive(nums):
    n = len(nums)

    # 1. Adım: Dizi elemanlarını uygun indekslerine yerleştir
    for i in range(n):
        while 1 <= nums[i] <= n and nums[nums[i] - 1] != nums[i]:
            # Elemanları yer değiştir
            nums[nums[i] - 1], nums[i] = nums[i], nums[nums[i] - 1]

    # 2. Adım: İlk eksik pozitif tamsayıyı bul
    for i in range(n):
        if nums[i] != i + 1:
            return i + 1

    # Tüm elemanlar doğru yerindeyse, eksik olan tamsayı n + 1'dir
    return n + 1

# Örnek kullanım
nums = [3, 4, -1, 1]
print("First missing positive:", first_missing_positive(nums))  # Çıktı: 2

nums = [1, 2, 0]
print("First missing positive:", first_missing_positive(nums))  # Çıktı: 3




#include <iostream>
#include <vector>
using namespace std;

int firstMissingPositive(vector<int>& nums) {
    int n = nums.size();

    // 1. Adım: Dizi elemanlarını uygun indekslerine yerleştir
    for (int i = 0; i < n; i++) {
        while (nums[i] > 0 && nums[i] <= n && nums[nums[i] - 1] != nums[i]) {
            swap(nums[i], nums[nums[i] - 1]);
        }
    }

    // 2. Adım: İlk eksik pozitif tamsayıyı bul
    for (int i = 0; i < n; i++) {
        if (nums[i] != i + 1) {
            return i + 1;
        }
    }

    // Tüm elemanlar doğru yerindeyse, eksik olan tamsayı n + 1'dir
    return n + 1;
}

int main() {
    vector<int> nums = {3, 4, -1, 1};
    cout << "First missing positive: " << firstMissingPositive(nums) << endl;
    return 0;
}
